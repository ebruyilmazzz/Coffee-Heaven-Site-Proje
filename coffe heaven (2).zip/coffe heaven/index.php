<!DOCTYPE html>
<Html lang="tr">
    <head>
        <meta charset="utf-8">
        <title>COFFE HEAVEN|Ana Sayfa </title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
       
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    </head>

    <body>
    
         <section id="menu">
            <div id="logo">COFFE HEAVEN </div>
                <i><img src="image/WhatsApp Görsel 2024-05-31 saat 14.25.46_f9a883be.jpg" alt="" width="75px"></i>
                
               <nav>
                <a href="sogukicecek.php"><i class="fa-solid fa-mug-saucer"></i>Soğuk İçecekler</a>
                <a href="sicakicecekler.php"><i class="fa-solid fa-mug-hot"></i>Sıcak İçecekler</a>
                <a href="index.php"><i class="fa-solid fa-house"></i>ANA SAYFA</a>
                <a href="siparis.php"><i class="fa-solid fa-mug-saucer"></i>Sipariş Oluştur</a>
                <a href="kayit.php"><i class="fa-solid fa-user-plus"></i>ÜYE OL</a>
                <a href="cikis.php"><i class="fa-solid fa-user-plus"></i>GİRİS</a>
            </nav>
         </section>
         
         <section id="anasayfa">
            <div id="black">
            </div>
            <div id="icerik">
                <h2>HOŞGELDİNİZ</h2>
                <hr width=300 align="left" >
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Reiciendis veniam facere velit nisi placeat fugit. Illum temporibus in, rerum dolorum perspiciatis fugit id accusamus laborum dolores odio sint quaerat tenetur!</p>
            </div>
            <section class="hero">
        <div class="hero-content">
            <h2>Kendinizi Baştan Yaratın</h2>
            <p>Profesyonel Saç ve Güzellik Hizmetleri</p>
            <a href="siparis.php" class="btn">Sipariş Oluştur</a>
        </div>
    </section>
            
    <footer id="footer">
        <h1 class="text-center">COFFE HEAVEN</h1>
        <p class="text-center">İLETİŞİM<br>
            0850 308 1552<br>
            coffeheaven@.com</p>
        
      
    </footer>
    </body>  
</Html>


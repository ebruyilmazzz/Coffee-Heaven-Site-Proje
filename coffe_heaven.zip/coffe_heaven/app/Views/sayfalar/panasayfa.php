  <!-- İçecekler Bölümü -->
  <section class="features">
            <div class="container">
                <div class="feature">
                    <img src="https://img.icons8.com/ios/50/coffee.png" alt="Kahve">
                    <h2>Süt</h2>
                    <p>Farklı kahve çeşitlerimiz ile sizi bekliyoruz.</p>
                </div>
                <div class="feature">
                    <img src="https://img.icons8.com/ios/50/tea.png" alt="Çay">
                    <h2>Çay</h2>
                    <p>Doğal çaylarımız ile ferahlayın.</p>
                </div>
                <div class="feature">
                    <img src="https://img.icons8.com/ios/50/cocktail.png" alt="Soğuk İçecekler">
                    <h2>Soğuk İçecekler</h2>
                    <p>Yazın serinletici soğuk içeceklerimiz.</p>
                </div>
            </div>
        </section>
    </main>

 